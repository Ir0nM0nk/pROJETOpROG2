#include "Line.h"


Line::Line()
{}

Line::Line(string textLine)
{
	istringstream lineStr(textLine);
	string input;

	// Ler id

	getline(lineStr, input, ';');
	id = stoi(input);					//stoi tranforma string num n�mero inteiro
										
	// Ler frequ�ncia de circula��o

	getline(lineStr, input, ';');
	busFreq = stoi(input);

	// Ler lista de paragens

	getline(lineStr, input, ';');
	istringstream stopsStr(input);

	while (getline(stopsStr, input, ','))	//repete at� EOF
	{
		eraseExtraSpaces(input);
		busStopList.push_back(input);			//coloca cada paragem no vetor "stops" da classe
	}

	// Ler lista dos tempos de viagem

	while (getline(lineStr, input, ','))
		travelTimeList.push_back(stoi(input));			//coloca cada tempo de viagem no vetor "travelTimes" da classe

}

////////////////
// m�todos get
////////////////

uint Line::getId() const
{
	return id;
}

uint Line::getBusFreq() const
{
	return busFreq;
}

vector <string> Line::getBusStops() const
{
	return busStopList;
}

vector <uint> Line::getTravelTimes() const
{
	return travelTimeList;
}

////////////////
// m�todos set
////////////////

void Line::setId(uint newId)
{
	id = newId;
}

void Line::setBusFreq(uint newBusFreq)
{
	busFreq = newBusFreq;
}

void Line::setBusStops(vector <string> newBusStopList)
{
	busStopList = newBusStopList;
}

void Line::setBusStop(string newBusStop, uint i)
{
	if (i < busStopList.size())
		busStopList.at(i) = newBusStop;
}

void Line::setTravelTimes(vector <uint> newTravelTimeList)
{
	travelTimeList = newTravelTimeList;
}

void Line::setTravelTime(uint newTravelTime, uint i)
{
	if (i < travelTimeList.size())
		travelTimeList.at(i) = newTravelTime;
}