#include "Driver.h"


Driver::Driver()
{}

Driver::Driver(string textLine)
{
	istringstream driverStr(textLine);
	string input;

	// Ler id

	getline(driverStr, input, ';');
	id = stoi(input);					//stoi tranforma string num n�mero inteiro

	// Ler nome

	getline(driverStr, input, ';');
	eraseExtraSpaces(input);
	name = input;

	// Ler n� de horas consecutivas que pode trabalhar por dia

	getline(driverStr, input, ';');
	maxHours = stoi(input);

	// Ler n� m�ximo de horas que pode trabalhar por semana

	getline(driverStr, input, ';');
	maxWeekWorkingTime = stoi(input);

	// Ler n� m�nimo de horas de descanso obrigat�rio entre turnos

	getline(driverStr, input);
	minRestTime = stoi(input);
}

//////////////
// m�todos get
//////////////

uint Driver::getId() const
{
	return id;
}

string Driver::getName() const
{
	return name;
}

uint Driver::getShiftMaxDuration() const
{
	return maxHours;
}

uint Driver::getMaxWeekWorkingTime() const
{
	return maxWeekWorkingTime;
}

uint Driver::getMinRestTime() const
{
	return minRestTime;
}
/*
vector<Shift> Driver::getShifts() const{
  return shifts;
}
*/

//////////////
// m�todos set
//////////////

void Driver::setId(uint newId)
{
	id = newId;
}

void Driver::setName(string newName)
{
	name = newName;
}

void Driver::setShiftMaxDuration(uint newMaxHours)
{
	maxHours = newMaxHours;
}

void Driver::setMaxWeekWorkingTime(uint newMaxWeekWorkingTime)
{
	maxWeekWorkingTime = newMaxWeekWorkingTime;
}

void Driver::setMinRestTime(uint newMinRestTime)
{
	minRestTime = newMinRestTime;
}