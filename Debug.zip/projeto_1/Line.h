#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <sstream>

#include "auxfunc.h"

using namespace std;

typedef unsigned int uint;
 
class Line{

	public:
		Line();
		Line(string);
		// metodos get
		uint getId() const;
		uint getBusFreq() const;
		vector <string> getBusStops() const;
		vector <uint> getTravelTimes() const;
		// m�todos set
		void setId(uint);
		void setBusFreq(uint);
		void setBusStops(vector <string>);
		void setBusStop(string newBusStop, uint i);
		void setTravelTimes(vector <uint>);
		void setTravelTime(uint newTravelTime, uint i);
		// other methods

	private:
		uint id;
		uint busFreq;
		vector <string> busStopList;
		vector <uint> travelTimeList;
};