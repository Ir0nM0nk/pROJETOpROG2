#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <sstream>

#include "auxfunc.h"

//#include "Shift.h"

using namespace std;

typedef unsigned int uint;

class Driver{

	public:
		Driver();
		Driver(string);
		// m�todos get
		uint getId() const;
		string getName() const;
		uint getShiftMaxDuration() const;
		uint getMaxWeekWorkingTime() const;
		uint getMinRestTime() const;
		//vector<Shift> getShifts() const;
		// m�todos set
		void setId(uint);
		void setName(string);
		void setShiftMaxDuration(uint);
		void setMaxWeekWorkingTime(uint);
		void setMinRestTime(uint);

	private:
		uint id;
		string name;
		uint maxHours;						// n� de horas consecutivas que pode trabalhar por dia (um turno)
		uint maxWeekWorkingTime;			// n� m�ximo de horas que pode trabalhar por semana
		uint minRestTime;					// n� m�nimo de horas de descanso obrigat�rio entre turnos
		//vector<Shift> shifts;				// assigned shifts
};
