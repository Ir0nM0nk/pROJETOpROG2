#include <iostream>
#include <string>
#include <vector>
#include "Line.h"

using namespace std;

void ver_horario_line(int i, const vector <Line> &linesVec)
{
	//vector <Line> linesVec;
	//vector <Line> stops;
	int k, h_i, min_i, h_f, min_f, u = 0, tempo_i, tempo_f, h_ic, min_ic;
	cout << "Introduza a hora de in�cio do hor�rio : \n"; cout << "Hora: "; cin >> h_i; cout << "Minutos: "; cin >> min_i;
	cout << "Introduza a hora de fim do hor�rio : \n"; cout << "Hora: "; cin >> h_f; cout << "Minutos: "; cin >> min_f;
	h_ic = h_i;
	min_ic = min_i;


	for (k = 0; k < linesVec.at(i).getStops().size(); k++)
	{
		cout << linesVec.at(i).getStops().at(k) << " : " << endl << endl;
		tempo_i = (h_ic * 60 * 60) + min_ic * 60;
		tempo_f = (h_f * 60 * 60) + min_f * 60;
		h_i = h_ic;
		min_i = min_ic;

		if (k >= 1)
		{
			for (int lk = k; lk >= 1; lk--)
			{
				tempo_i += linesVec.at(i).getTravelTimes().at(lk - 1) * 60;
				min_i = min_i + linesVec.at(i).getTravelTimes().at(lk - 1);
			}

			h_i = h_i + min_i / 60;
			min_i = min_i % 60;
			h_i = h_i % 24;
		}
		int v = 0;


		while (tempo_i < tempo_f)
		{
			if (v == 9)
			{
				v = 0;
				cout << endl;
			}


			if (h_i < 10)
			{
				cout << "0";
			}
			cout << h_i << ":";
			if (min_i < 10)
			{
				cout << "0";
			}
			cout << min_i << " ";
			min_i = min_i + linesVec.at(i).getBusFreq();
			tempo_i = tempo_i + linesVec.at(i).getBusFreq() * 60;
			h_i = h_i + min_i / 60;
			min_i = min_i % 60;
			h_i = h_i % 24;
			v++;
		}
		cout << endl << endl;




	}

	system("pause");

}

void find_par()
{
	vector <int> paragens;
	vector <Line> linesVec;
	int   i, v, k, option;
	string nome_par;
	cout << "Introduza o nome da paragem : ";
	cin.clear();
	cin.ignore();
	getline(cin, nome_par);
	cout << endl;

	for (i = 0; i < linesVec.size(); i++)
	{

		for (k = 0; k < linesVec.at(i).getStops().size(); k++)
		{
			if (linesVec.at(i).getStops().at(k) == nome_par)
			{
				paragens.push_back(linesVec.at(i).getId());
				break;
			}

		}
	}

	if (paragens.size() == 0)
	{
		cout << "A paragem procurada n�o faz parte de nenhum dos percursos das linhas na base de dados. \n";

	}
	else
	{
		cout << "A paragem procurada est� inclu�da nos percursos das linhas : ";
		for (k = 0; k < (paragens.size() - 1); k++)
		{
			cout << paragens.at(k) << " , ";
		}
		cout << " e " << paragens.at(k) << " . ";
	}
	system("pause");
	cout << "Deseja ver o hor�rio da paragem ? \n" << "1-Sim \n" << "2-N�o \n"; cin >> option;
	/*switch (option)
	{
	case 1:
		//ver_horario_par(paragens);
	case 2:
		//menu_linhas();
	}*/
}

void ver_entre_par(int i)
{

	vector <Line> linesVec;
	vector<string> paragens;
	int duracao = 0, k, ind_i = 0, ind_f = 0;

	string paragem_i, paragem_f;
	cout << "Introduza a paragem de in�cio : "; cin.clear(); cin.ignore(); getline(cin, paragem_i);
	cout << "Introduza a paragem de fim : ";  getline(cin, paragem_f);
	for (k = 0; k < linesVec.at(i).getStops().size(); k++)
	{
		if (linesVec.at(i).getStops().at(k) == paragem_i)
		{
			ind_i = k;

		}

	}
	for (k = 0; k < linesVec.at(i).getStops().size(); k++)
	{
		if (linesVec.at(i).getStops().at(k) == paragem_f)
		{
			ind_f = k;

		}

	}
	cout << "Percurso : ";
	while (ind_i <= (ind_f - 1))
	{
		cout << linesVec.at(i).getStops().at(ind_i) << " - ";
		if (ind_i == 0)
		{
			duracao = duracao + linesVec.at(i).getTravelTimes().at(ind_i);

		}
		else
		{
			duracao = duracao + linesVec.at(i).getTravelTimes().at(ind_i - 1);
		}
		ind_i = ind_i + 1;

	}
	cout << linesVec.at(i).getStops().at(ind_i);
	cout << endl;
	cout << "Dura��o : " << duracao << endl;


	system("pause");
}