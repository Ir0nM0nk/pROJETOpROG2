#include <iostream>
#include <vector>
#include <string>

using namespace std;

void ver_horario_line(int i)
{
	vector <Line> linhas_totais = ler_linhas_vetor();
	int k, h_i, min_i, h_f, min_f, u = 0, tempo_i, tempo_f, h_ic, min_ic;
	cout << "Introduza a hora de in�cio do hor�rio : \n"; cout << "Hora: "; cin >> h_i; cout << "Minutos: "; cin >> min_i;
	cout << "Introduza a hora de fim do hor�rio : \n"; cout << "Hora: "; cin >> h_f; cout << "Minutos: "; cin >> min_f;
	h_ic = h_i;
	min_ic = min_i;


	for (k = 0; k < linhas_totais.at(i).paragens.size(); k++)
	{
		cout << linhas_totais.at(i).paragens.at(k) << " : " << endl << endl;
		tempo_i = (h_ic * 60 * 60) + min_ic * 60;
		tempo_f = (h_f * 60 * 60) + min_f * 60;
		h_i = h_ic;
		min_i = min_ic;

		if (k >= 1)
		{
			for (int lk = k; lk >= 1; lk--)
			{
				tempo_i += (linhas_totais.at(i).tempos.at(lk - 1)) * 60;
				min_i = min_i + linhas_totais.at(i).tempos.at(lk - 1);
			}

			h_i = h_i + min_i / 60;
			min_i = min_i % 60;
			h_i = h_i % 24;
		}
		int v = 0;


		while (tempo_i < tempo_f)
		{
			if (v == 9)
			{
				v = 0;
				cout << endl;
			}


			if (h_i < 10)
			{
				cout << "0";
			}
			cout << h_i << ":";
			if (min_i < 10)
			{
				cout << "0";
			}
			cout << min_i << " ";
			min_i = min_i + (linhas_totais.at(i).freq);
			tempo_i = tempo_i + (linhas_totais.at(i).freq) * 60;
			h_i = h_i + min_i / 60;
			min_i = min_i % 60;
			h_i = h_i % 24;
			v++;
		}
		cout << endl << endl;




	}

	system("pause");

}

void find_par()
{
	vector <int> paragens;
	vector <Linha> linhas_totais = ler_linhas_vetor();
	int   i, v, k, option;
	string nome_par;
	Limpar_ecra();
	cout << "Introduza o nome da paragem : ";
	cin.clear(); cin.ignore(); getline(cin, nome_par);
	cout << endl;

	for (i = 0; i < linhas_totais.size(); i++)
	{

		for (k = 0; k < linhas_totais.at(i).paragens.size(); k++)
		{
			if (linhas_totais.at(i).paragens.at(k) == nome_par)
			{
				paragens.push_back(linhas_totais.at(i).id);
				break;
			}

		}
	}

	if (paragens.size() == 0)
	{
		cout << "A paragem procurada n�o faz parte de nenhum dos percursos das linhas na base de dados. \n";

	}
	else
	{
		cout << "A paragem procurada est� inclu�da nos percursos das linhas : ";
		for (k = 0; k < (paragens.size() - 1); k++)
		{
			cout << paragens.at(k) << " , ";
		}
		cout << " e " << paragens.at(k) << " . ";
	}
	system("pause");
	cout << "Deseja ver o hor�rio da paragem ? \n" << "1-Sim \n" << "2-N�o \n"; cin >> option;
	switch (option)
	{
	case 1:
		ver_horario_par(paragens);
	case 2:
		menu_linhas();
	}
}

void ver_entre_par(int i)
{
	SetConsoleCP(1252);
	SetConsoleOutputCP(1252);
	vector <Linha> linhas_totais = ler_linhas_vetor();
	vector<string> paragens;
	int duracao = 0, k, ind_i = 0, ind_f = 0;

	string paragem_i, paragem_f;
	cout << "Introduza a paragem de in�cio : "; cin.clear(); cin.ignore(); getline(cin, paragem_i);
	cout << "Introduza a paragem de fim : ";  getline(cin, paragem_f);
	for (k = 0; k < linhas_totais.at(i).paragens.size(); k++)
	{
		if (linhas_totais.at(i).paragens.at(k) == paragem_i)
		{
			ind_i = k;

		}

	}
	for (k = 0; k < linhas_totais.at(i).paragens.size(); k++)
	{
		if (linhas_totais.at(i).paragens.at(k) == paragem_f)
		{
			ind_f = k;

		}

	}
	cout << "Percurso : ";
	while (ind_i <= (ind_f - 1))
	{
		cout << linhas_totais.at(i).paragens.at(ind_i) << " - ";
		if (ind_i == 0)
		{
			duracao = duracao + linhas_totais.at(i).tempos.at(ind_i);

		}
		else
		{
			duracao = duracao + linhas_totais.at(i).tempos.at(ind_i - 1);
		}
		ind_i = ind_i + 1;

	}
	cout << linhas_totais.at(i).paragens.at(ind_i);
	cout << endl;
	cout << "Dura��o : " << duracao << endl;


	system("pause");
}