/*
FICHEIRO   : filemanip.cpp
DATA   : 2017/04/10
AUTOR : SS
FINALIDADE:
-Defini��o de fun��es para leitura dos ficheiros
*/

#include "filemanip.h"


/*
L� os dados relativos a cada linha contidas no ficheiro
e guarda tudo num vetor de structs.
@param in - stream de entrada de onde l� a informa��o
@valor de retorno: vetor de structs "line", com informa��o de cada linha
*/
void readLines(ifstream &in, vector <Line> &linesVec)
{
	string inputLine;										//string que cont�m cada linha completa

	// Ler as v�rias linhas uma a uma

	while (getline(in, inputLine))							//repete enquanto n�o chegar ao fim do ficheiro (EOF)
	{
		Line newLine(inputLine);							// inicializa a linha e decomp�e toda a informa��o presente na string
		linesVec.push_back(newLine);						
	}
}

/*
L� os dados relativos a cada condutor e guarda tudo num
vetor de structs "driver"
@param in - stream de input de onde vai ler a informa��o
@valor de retorno: vetor de structs "driver", com informa��o de cada condutor
*/
void readDrivers(ifstream &in, vector <Driver> &driversVec)
{
	string inputDriver;									//string que cont�m toda informa��o do condutor

	while (getline(in, inputDriver))
	{
		Driver newDriver(inputDriver);					// inicializa o condutor e decomp�e toda a informa��o presente na string
		driversVec.push_back(newDriver);
	}
}

//---------------------------------

/*
Carrega a informa��o do ficheiro das linhas e do ficheiro dos condutores
para os vetores. Termina o programa com erro caso os ficheiros introduzidos
sejam inv�lidos.
@param linesVec - vetor para onde s�o guardadas as linhas
@param driversVec - vetor para onde s�o guardados os condutores
*/
void loadFiles(vector <Line> &linesVec, vector <Driver> &driversVec)
{
	string fileName;
	ifstream linesInput, driversInput;

	cout << "Introduza os seguintes ficheiros\n\n";

	//Bloco respons�vel por ligar stream linesInput ao ficheiro das linhas

	cout << "Ficheiro das linhas (nome.txt ou diretorio\\nome.txt)\n";
	getline(cin, fileName);
	cout << endl;

	linesInput.open(fileName);
	if (linesInput.fail())
	{
		cerr << "Ficheiro invalido... Programa terminado\n";
		exit(1);
	}

	//Bloco respons�vel por ligar stream driversInput ao ficheiro dos condutores

	cout << "Ficheiro dos condutores (nome.txt ou diretorio\\nome.txt)\n";
	getline(cin, fileName);
	cout << endl;

	driversInput.open(fileName);
	if (driversInput.fail())
	{
		cerr << "Ficheiro invalido... Programa terminado\n";
		exit(1);
	}

	//---------------------------

	readLines(linesInput, linesVec);
	readDrivers(driversInput, driversVec);

	linesInput.close();
	driversInput.close();			//fechar ambos os ficheiros porque j� n�o s�o precisos
	cout << "Ficheiros carregados com sucesso\n";
}