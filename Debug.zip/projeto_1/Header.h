#pragma once
void ver_horario_line(int i, const vector <Line> &linesVec);
void find_par();
void ver_entre_par(int i);