/*
FICHEIRO	: linemanip.h
DATA		: 2017/04/15
AUTOR		: SS
FINALIDADE:
-prot�tipos das fun��es definidas em linemanip.cpp
*/

#pragma once

#include <iostream>
#include <vector>
#include <string>

#include "Line.h"
#include "auxfunc.h"

using namespace std;

/*
Seleciona a op��o correspondente ao tipo de altera��o que o utilizador
pretende fazer nos dados das linhas
@param linesVec - vetor das linhas
*/
void lineManagement(vector <Line> &linesVec);