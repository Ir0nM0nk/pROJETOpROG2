/*
FICHEIRO   : drivermanip.cpp
DATA   : 2017/04/16
AUTOR : SS
FINALIDADE:
-Defini��o de fun��es para gest�o dos condutores
*/

#include "drivermanip.h"

/*
Display do sub-menu relativo � gest�o de condutores (op��o 2)
*/
void showDriverSubMenu()
{
	cout << endl;
	showIntro();

	cout << "Selecione uma opcao\n\n";
	cout << "1 - Adicionar condutor\n";
	cout << "2 - Alterar condutor\n";
	cout << "3 - Remover condutor\n";
	cout << "9 - Voltar\n\n";
}

/*
Mostrar as op��es de altera��o do condutor
*/
void showDriverOptions()
{
	cout << endl;
	showIntro();

	cout << "Selecione a informacao a alterar\n\n"
		<< "1 - ID\n"
		<< "2 - Nome\n"
		<< "3 - Numero de horas consecutivas que pode conduzir por dia\n"
		<< "4 - Numero maximo de horas que pode conduzir por semana\n"
		<< "5 - Numero minimo de horas de descanso obrigatorio\n"
		<< "9 - Voltar\n\n";
}

/*
Procura um id numa estrutura de dados
@param id - id a verificar
@param vec - vetor que cont�m dados a comparar
@valor de retorno: -1 caso n�o encotre o id, ou pos (indice da posi��o)
caso encontre
*/
int searchDriverId(const uint &id, const vector <Driver> &vec)
{
	for (size_t pos = 0; pos < vec.size(); pos++)
	{
		if (id == vec.at(pos).getId())
			return pos;
	}
	return -1;
}

//-------------------------

/*
L� o novo nome do condutor
@param name - nome do condutor
*/
void readName(string &name)
{
	cout << "Insira o nome: ";
	
	while (!getline(cin, name))
	{
		cin.clear();
		cout << "Entrada invalida\n";
		cout << "Insira o nome: ";
	}

	eraseExtraSpaces(name);
}

/*
L� o n�mero de horas consecutivas que pode conduzir por dia (um turno)
@param maxHours - n�mero de horas consecutivas que pode conduzir por dia (um turno)
*/
void readMaxHours(int &maxHours)
{
	cout << "Num. max. de horas consecutivas que pode conduzir por dia: ";

	while (!readPositiveInt(maxHours))		// enquanto a entrada for invalida ou freq <=0
	{
		cerr << "Entrada invalida\n";
		cout << "Num. max. de horas consecutivas que pode conduzir por dia: ";
	}
}

/*
L� o n�mero m�ximo de horas que pode conduzir por semana
@param maxWeekWorkingTime - n�mero m�ximo de horas que pode conduzir por semana
*/
void readMaxWeekWorkingTime(int &maxWeekWorkingTime)
{
	cout << "Num. max. de horas que pode conduzir por semana: ";

	while (!readPositiveInt(maxWeekWorkingTime))		// enquanto a entrada for invalida ou freq <=0
	{
		cerr << "Entrada invalida\n";
		cout << "Num. max. de horas que pode conduzir por semana: ";
	}
}

/*
L� o n�mero m�nimo de horas de descanso obrigat�rio
@param minRestTime - n�mero m�nimo de horas de descanso obrigat�rio
*/
void readMinRestTime(int &minRestTime)
{
	cout << "Num. min. de horas de descanso obrigatorio: ";

	while (!readPositiveInt(minRestTime))		// enquanto a entrada for invalida ou freq <=0
	{
		cerr << "Entrada invalida\n";
		cout << "Num. min. de horas de descanso obrigatorio: ";
	}
}

//-------------------------

/*
L� a informa��o completa de um condutor e armazena no vetor dos condutores
@param driversVec - vetor dos condutores
@valor de retorno: true caso o condutor tenha sido adicionado com sucesso
*/
bool addDriver(vector <Driver> &driversVec)
{
	Driver newDriver;
	int newId, maxHours, maxWeekWorkingTime, minRestTime;
	string name;

	readId(newId);
	// verificar se o ID j� existe e terminar caso afirmativo
	if (searchDriverId(newId, driversVec) != -1)			//esta fun��o retorna -1 caso n�o encontre o id na estrutura
		return false;

	cout << endl;
	readName(name);
	cout << endl;
	readMaxHours(maxHours);
	cout << endl;
	readMaxWeekWorkingTime(maxWeekWorkingTime);
	cout << endl;
	readMinRestTime(minRestTime);

	newDriver.setId(newId);
	newDriver.setName(name);
	newDriver.setShiftMaxDuration(maxHours);
	newDriver.setMaxWeekWorkingTime(maxWeekWorkingTime);
	newDriver.setMinRestTime(minRestTime);

	driversVec.push_back(newDriver);

	return true;
}

//------------------------------

/*
Seleciona a op��o correspondente ao tipo de altera��o que o utilizador
pretende fazer no condutor
@param driverStruct - struct com dados do condutor que se pretende alterar
@param driversVec - vetor dos condutores para verificar se existe repeti��o
do id introduzido pelo utilizador (aquando da modifica��o)
*/
void changeDriver(Driver &driver, vector <Driver> &driversVec)
{
	uint option;		// informa��o a alterar

	do
	{
		showDriverOptions();
		readOption(option);
		/*
		1 - ID
		2 - Nome
		3 - N�mero de horas consecutivas que pode conduzir por dia (um turno)
		4 - N�mero m�ximo de horas que pode conduzir por semana
		5 - N�mero m�nimo de horas de descanso obrigat�rio
		9 - Voltar
		*/
		switch (option)
		{
		case 1:		//ler novo ID e guardar
			int newId;
			readId(newId);
			if (searchDriverId(newId, driversVec) == -1)			//verificar se newID n�o existe no vetor de condutores
				driver.setId(newId);
			else
				cerr << "\nERRO - ID ja existente\n";
			break;
		case 2:
		{
			string newName;
			readName(newName);
			driver.setName(newName);
			break;
		}
		case 3:
			int newMaxHours;
			readMaxHours(newMaxHours);
			driver.setShiftMaxDuration(newMaxHours);
			break;
		case 4:
			int newMaxWeekWorkingTime;
			readMaxWeekWorkingTime(newMaxWeekWorkingTime);
			driver.setMaxWeekWorkingTime(newMaxWeekWorkingTime);
			break;
		case 5:
			int newMinRestTime;
			readMinRestTime(newMinRestTime);
			driver.setMinRestTime(newMinRestTime);
			break;
		case 9:
			break;
		default:
			cerr << "Opcao invalida\n";
		}
	} while (option != 9);
}

/*
Fun��o respons�vel por alterar os dados dos condutores pretendidos pelo utilizador
@param driversVec - vetor dos condutores
@valor de retorno - retorna false caso o ID do condutor que se pretende alterar n�o exista
*/
bool changeDriver(vector <Driver> &driversVec)
{
	int id;

	// Ler o id do condutor a alterar
	cout << "ID do condutor a alterar: ";
	while (!readPositiveInt(id))		// enquanto a entrada for invalida ou id <=0
	{
		cerr << "Entrada invalida\n";
		cout << "ID do condutor a alterar: ";
	}

	int pos = searchDriverId(id, driversVec);			// �ndice da linha com id introduzido
	// retornar false caso id n�o seja encontrado
	if (pos == -1)
		return false;

	// Realizar altera��es
	changeDriver(driversVec.at(pos), driversVec);
	return true;
}

//-------------------------------

/*
Fun��o respons�vel por eliminar os dados de um condutor selecionado pelo utilizador
@param driversVec - vetor dos condutores
@valor de retorno - retorna false caso o ID do condutor que se pretende remover n�o exista
*/
bool removeDriver(vector <Driver> &driversVec)
{
	int id;

	// Ler o id do condutor a remover
	cout << "ID do condutor a remover: ";
	while (!readPositiveInt(id))		// enquanto a entrada for invalida ou id <=0
	{
		cerr << "Entrada invalida\n";
		cout << "ID do condutor a remover: ";
	}

	int pos = searchDriverId(id, driversVec);			// �ndice do condutor com id introduzido
	// retornar false caso id n�o seja encontrado
	if (pos == -1)
		return false;

	driversVec.erase(driversVec.begin() + pos);

	return true;
}

//-------------------------------

/*
Seleciona a op��o correspondente ao tipo de altera��o que o utilizador
pretende fazer nos dados dos condutores
@param driversVec - vetor dos condutores
*/
void driverManagement(vector <Driver> &driversVec)
{
	uint option;

	do
	{
		showDriverSubMenu();
		readOption(option);
		/*
		1 - Adicionar condutor
		2 - Alterar condutor
		3 - Remover condutor
		9 - Voltar
		*/
		switch (option)
		{
		case 1:
			if (addDriver(driversVec))
				cout << "\nCondutor adicionado com sucesso\n";
			else
				cerr << "\nErro - Condutor ja existente\n";
			break;
		case 2:
			if (changeDriver(driversVec))
				cout << "\nAlteracao guardada com sucesso\n";
			else
				cerr << "\nErro - Condutor nao encontrado\n";
			break;
		case 3:
			if (removeDriver(driversVec))
				cout << "\nCondutor removido com sucesso\n";
			else
				cerr << "\nErro - Condutor nao encontrado\n";
			break;
		case 9:
			break;
		default:
			cerr << "Opcao invalida\n";
		}
	} while (option != 9);			//enquanto option n�o for 9
}