/*
FICHEIRO   : auxfunc.h
DATA   : 2017/04/10
AUTOR : SS
FINALIDADE:
-Prot�tipos de fun��es definidas em auxfunc.cpp
*/

#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <sstream>

#include "Line.h"
#include "Driver.h"

typedef unsigned int uint;

using namespace std;

/*
Display de uma introdu��o
*/
void showIntro();
/*
Display do menu principal
*/
void showMenu();
/*
Elimina espa�os extra na string
@param str - string a alterar
*/
void eraseExtraSpaces(string &str);
/*
L� op��o a executar
@param option - op��o a introduzir pelo utilizador
*/
void readOption(uint &option);
/*
L� um valor inteiro introduzido pelo utilizador.
Este valor deve ser maior que 0.
@param num - numero a ler
@valor de retorno: true caso leitura seja v�lida
*/
bool readPositiveInt(int &num);

/*
L� o id introduzido pelo utilizador
@param id - id a ser introduzido
*/
void readId(int &id);